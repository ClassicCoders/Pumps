
alpr -c eu -j $1 > /var/www/html/uploads/last.json
php /var/www/html/getreg_details.php uploads/last.json > /var/www/html/uploads/last2.json
cat /var/www/html/uploads/last2.json
