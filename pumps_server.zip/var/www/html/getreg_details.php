<?php
header("Access-Control-Allow-Origin: *" );
// Network Rail Stomp Handler example by ian13
$server = "https://dvlasearch.appspot.com/";
$query = "DvlaSearch?licencePlate=";
$key = "&apikey=youngrewiredstate";
$basedir = "/var/www/html";
$timeout =0;
date_default_timezone_set('UTC');

function read_callback($ch, $fd, $length)
{
    $string = fread( $fd, $length );
    return $string; 
}

function boolString($bValue = false) {                      // returns string
   return ($bValue ? 'true' : 'false');
 }


$curl_option_defaults = array(
    CURLOPT_HEADER => false,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 2
  ); 

// Generic Curl REST function.
// Connection are created demand and closed by PHP on exit.
function curl_rest($method,$uri,$query=NULL,$key = NULL ){
  global $curl_url,$curl_handle,$curl_option_defaults;

  // Connect 
  if(!isset($curl_handle)) $curl_handle = curl_init();

#  echo "DB operation: $method $uri $query $json\n";
  // Compose query
  $options = array(
    CURLOPT_URL => $curl_url.$uri.$query.$key,
    CURLOPT_CUSTOMREQUEST => $method, // GET POST PUT PATCH DELETE HEAD OPTIONS 
    CURLOPT_POST => FALSE,
        CURLOPT_RETURNTRANSFER => TRUE, 
        CURLOPT_TIMEOUT => 4 

  ); 
  curl_setopt_array($curl_handle,($options + $curl_option_defaults)); 

  // send request and wait for response
  $response =  curl_exec($curl_handle);
#  echo "Response from DB: \n";
#  print_r($response);
  
  return($response);
}
$string = file_get_contents( $argv[1] );
$json_ = json_decode( $string );
#print_r( $json_);
if( property_exists($json_, "results" ) &&
    array_key_exists(  0, $json_->results ) ){
   $plate= $json_->results[0]->plate;
   $cache_name =  $basedir . "/cache/" . $plate . ".json";
   if( file_exists( $basedir . "/cache/" . $plate . ".json" ) ){
     $details_text = file_get_contents( $cache_name );
   } else {
     $details_text =  curl_rest( "GET", $server, $query .$plate,$key);
     file_put_contents( $cache_name, $details_text );
   }
   $details = json_decode( $details_text );
   $json_->dvla = $details;
   print( json_encode( $json_ ) );
   } else{
   print( "{}" );
   } 
?>

