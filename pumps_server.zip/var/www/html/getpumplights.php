<?php
$string = file_get_contents("/var/www/html/uploads/last2.json");
$json_a = json_decode($string, true);
#print_r( $json_a );
if( is_array( $json_a) && 
    array_key_exists( 'dvla', $json_a ) &&
    array_key_exists(  'fuelType', $json_a['dvla'] )){
   print( $json_a['dvla']['fuelType'] ) ;
}else{
print("unknown" );
}
?>