<?php
header("Access-Control-Allow-Origin: *" );
$server = "https://dvlasearch.appspot.com/";
$query = "DvlaSearch?licencePlate=";
$key = "&apikey=youngrewiredstate";
$basedir = "/var/www/html";

$curl_option_defaults = array(
    CURLOPT_HEADER => false,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 2
  ); 

// Generic Curl REST function.
// Connection are created demand and closed by PHP on exit.
function curl_rest($method,$uri,$query=NULL,$key = NULL ){
  global $curl_url,$curl_handle,$curl_option_defaults;

  // Connect 
  if(!isset($curl_handle)) $curl_handle = curl_init();

#  echo "DB operation: $method $uri $query $json\n";
  // Compose query
  $options = array(
    CURLOPT_URL => $curl_url.$uri.$query.$key,
    CURLOPT_CUSTOMREQUEST => $method, // GET POST PUT PATCH DELETE HEAD OPTIONS 
    CURLOPT_POST => FALSE,
        CURLOPT_RETURNTRANSFER => TRUE, 
        CURLOPT_TIMEOUT => 4 

  ); 
  curl_setopt_array($curl_handle,($options + $curl_option_defaults)); 

  // send request and wait for response
  $response =  curl_exec($curl_handle);
#  echo "Response from DB: \n";
#  print_r($response);
  
  return($response);
}



   $plate= $_GET[ 'numberplate'];
   $cache_name =  $basedir . "/cache/" . $plate . ".json";
   if( file_exists( $cache_name ) ){
     $details_text = file_get_contents( $cache_name );
   } else {
     $details_text = curl_rest( "GET", $server, $query .$plate,$key);
     file_put_contents( $cache_name, $details_text );
   }
   print( $details_text );
   $details = json_decode( $details_text );
   $json_ = new stdClass();
   $json_->dvla = $details;
   file_put_contents( $basedir . "/uploads/last2.json", json_encode( $json_ ) );


?>
